﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=MARINDIMITR2641;Database=MusicHub;Trusted_Connection=True";
    }
}
